#include "PassThePigs.h"
#include <ctime>
#include <iostream>
#include <cstdlib>

using namespace std;

void displayGameRules(){
    cout << "Each turn involves one player throwing two model pigs, each of which has a dot on one side. The player gains or loses points, or is eliminated from the game based on the way the pigs land. Each turn lasts until the player throwing either rolls the pigs in a way that wipes out their current turn score, wipes out their total game score, or decides to stop their turn, add their turn score to their total score and pass the pigs to the next player." << endl;
}

bool isValidWinningScore(int y){
    if(y<0 || y>100){
        return false;
    }
    return true;
}

int getValidWinningScore(){
    int x;
    cout << "How many points do you want to play until? (enter an integer between 1 and 100 inclusive)" << endl;
    cin >> x;
    isValidWinningScore(x);
    if(isValidWinningScore(x) == true){
        return x;
    }else{
        getValidWinningScore();
    }
    //return x;
}

string rollPig(int n){
    srand(time(0));
    if(n >= 0 && n <=35){
        return "SIDE";
    }
    else if(n >= 36 && n <=65 ){
        return "SIDE-D";
    }
    else if(n >= 66 && n <=85){
        return "RZR";
    }
    else if(n >= 86 && n <=95){
        return "TROT";
    }
    else if(n >= 96 && n <=99){
        return "SNOUT";
    }
    else{
        return "LEAN";
    }
}

string determineRollResults(string roll1, string roll2){
    if(roll1=="SIDE" && roll2=="SIDE"){
        return "SIDER";
    }
    else if(roll1=="SIDE-D" && roll2=="SIDE-D"){
        return "SIDER";
    }
    else if(roll1=="RZR" && roll2=="RZR"){
        return "DBL-RAZR";
    }
    else if(roll1=="TROT" && roll2=="TROT"){
        return "DBL-TROT";
    }
    else if(roll1=="SNOUT" && roll2=="SNOUT"){
        return "DBL-SNOUT";
    }
    else if(roll1=="LEAN" && roll2=="LEAN"){
        return "DBL-LEAN";
    }
    else if((roll1=="SIDE-D" && roll2=="SIDE") || (roll2=="SIDE-D" && roll1=="SIDE")){
        return "PIGOUT";
    }
    else{
        return "MIXED";
    }
}

int calculateTotalRollPoints(string roll1, string roll2, string rollResult){
    if(rollResult == "SIDER"){
        return 1;
    }
    else if(rollResult == "DBL-RAZR"){
        return 20;
    }
    else if(rollResult == "DBL-TROT"){
        return 20;
    }
    else if(rollResult == "DBL-SNOUT"){
        return 40;
    }
    else if(rollResult == "DBL-LEAN"){
        return 60;
    }
    else if(rollResult == "PIGOUT"){
        return 0;
    }
    else{
        int sum = 0;
        if(roll1 == "RZR" || roll1 == "TROT"){
            sum+=5;
        }
        else if(roll1 == "SNOUT"){
            sum+=10;
        }   
        else if(roll1 == "LEAN"){
            sum+=15;
        }
        else{
            sum+=0;
        }
        
        
        if(roll2 == "RZR" || roll2 == "TROT"){
            sum+=5;
        }
        else if(roll2 == "SNOUT"){
            sum+=10;
        }
        else if(roll1 == "LEAN"){
            sum+=15;
        }
        else{
            sum+=0;
        }
        return sum;
    }

}