#include "PassThePigs.h"
#include <iostream>
#include <string>
#include <ctime>

using namespace std;

int main() {
    int x, score, scoreSum = 0, scoreSum2 = 0, count, pig1, pig2;
    string result, roll1, roll2, enter;
    srand(time(0));
    displayGameRules();
    x = getValidWinningScore();
    cin.ignore();
    
    while(scoreSum<x && scoreSum2<x){
    
        cout << "Player 1 turn: " << endl; 
        count = 0;
        while(scoreSum<x && scoreSum2<x){
            count++;
            pig1 = (rand() % (100-1+1))+1;
            pig2 = (rand() % (100-1+1))+1;
            roll1 = rollPig(pig1);
            roll2 = rollPig(pig2);
            cout << roll1 << " and " << roll2 << endl;
            result = determineRollResults(roll1, roll2);
            cout << result << endl;
            score = calculateTotalRollPoints(roll1, roll2, result);
            cout << "Roll score: " << score << endl;
            if(count == 5){
                cout << "5 rolls in a row!? You have some guts!" << endl;
            }
            else if(count == 7){
                cout << "I think you have a gambling problem... 7 roles is insane!!!!!" << endl;
            }
            if(result == "PIGOUT"){
                scoreSum = 0;
                cout << "Awwww! Is player 1 gonna be a little baby now? You just got pigged out!" << endl;
                break;
            }
            scoreSum += score;
            cout << "Player 1 total: " << scoreSum << endl;
            if(scoreSum < x){
                cout << "Press enter to continue rolling or n to end turn: " << endl;
                getline(cin, enter);
                if(enter == "n"){
                    break;
                }
            }
            else{}
        }
       
       // getline(cin, enter);
        cout << "Press enter to continue playing or n to exit and end the game: " << endl;
        getline(cin, enter);
        if(enter == "n"){
            x=0;
        }
        count = 0;
        cout << "Player 2 turn: " << endl;
        while(scoreSum<x && scoreSum2<x){
            count++;
            pig1 = (rand() % (100-1+1))+1;
            pig2 = (rand() % (100-1+1))+1;
            roll1 = rollPig(pig1);
            roll2 = rollPig(pig2);
            cout << roll1 << " and " << roll2 << endl;
            result = determineRollResults(roll1, roll2);
            cout << result << endl;
            score = calculateTotalRollPoints(roll1, roll2, result);
            cout << "Roll score: " << score << endl;
            scoreSum2 += score;
            if(count == 5){
                cout << "5 rolls in a row!? You have some guts!" << endl;
            }
            else if(count == 7){
                cout << "I think you have a gambling problem... 7 roles is insane!!!!!" << endl;
            }
            if(result == "PIGOUT"){
                scoreSum2 = 0;
                cout << "C'mon piggy! I know you're better than that! Looks like you're going back to the pen!" << endl;
                break;
            }
            
            cout << "Player 2 total: " << scoreSum2 << endl;
            if(scoreSum2<x){
                cout << "Press enter to contiue rolling or n to end turn: " << endl;
                getline(cin, enter);
                if(enter == "n"){
                    break;
                }
            }
        }
        if(scoreSum<x && scoreSum2<x){
            cout << "\nPress enter to contiue playing or n to exit and end the game: " << endl;
            getline(cin, enter);
            if(enter == "n"){
                x=0;
            }
        }
        if(scoreSum2>scoreSum){
            cout << "Player 2 is in the lead!" << endl;
        }else{
            cout << "Player 1 is in the lead!" << endl;
        }
    }

    if(scoreSum > scoreSum2){
        cout << "Player 1 wins!!!!!!!!" << endl;
    }
    else if(scoreSum == scoreSum2){
        cout << "We have a tie!!!!" << endl;
    }
    else{
        cout << "Player 2 wins!!!!!!!!" << endl;
    }
        
    return 0;
}