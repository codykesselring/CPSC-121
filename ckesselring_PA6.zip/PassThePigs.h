#ifndef PASS_THE_PIGS_H
#define PASS_THE_PIGS_H

#include <string>
using namespace std;

void displayGameRules();
int getValidWinningScore();
bool isValidWinningScore(int y);
string rollPig(int roll);
string determineRollResults(string roll1, string roll2);
int calculateTotalRollPoints(string roll1, string roll2, string rollResult);

#endif